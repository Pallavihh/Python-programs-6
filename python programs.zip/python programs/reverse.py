text = input("Enter a string")
reverse = text [::-1]
print("Reverse a string:", reverse)